package com.profesorinterino;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfesorInterinoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProfesorInterinoApplication.class, args);
    }
}
